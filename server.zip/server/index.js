const  express = require("express");
const app = express();
const mongoose = require("mongoose");
const itemsModel = require('./models/Items')
const cors = require("cors");


app.use(express.json());
app.use(cors());
mongoose.connect("mongodb+srv://qlm5011:Password123@cluster0.nbyvwn0.mongodb.net/proj2?retryWrites=true&w=majority");


app.get("/getItems", async (req, res) => {
    try {
        const result = await itemsModel.find({});
        res.json(result);
    } catch (err) {
        res.json(err);
    }
});


app.post("/createItems",async (req,res) => {
    const item =  req.body;
    const newItem = new itemsModel (item);
    await newItem.save();

    res.json(item);


    });

app.put("/UpdateItems", async (req, res) => {

const newDesc = req.body.newDesc;
const id = req.body.id;
console.log(newDesc,id);

try {
    await itemsModel.findById(id, (error, DesctoUpdate)=> {

        DesctoUpdate.description = newDesc;
        DesctoUpdate.save();
    });
    
} catch (err) {
    console.log(err);
    
}
res.send("updated!");


});

app.post("/deleteItem", async (req,res) => {
    const {id }= req.body;
    try{
        itemsModel.deleteOne({_id: id}, function(err, res) {
            console.log(err);
        });
    } catch(error) {
        console.log(error);
        
    }
    

   
});




app.listen(3001, () => {
console.log("Server runs!");

});